<ul>
	<li><a href="{{URL('about/profile')}}">Profil Perusahaan</a></li>
    <li><a href="{{URL('about/visimisi')}}">Visi Misi & Nilai Perusahaan</a></li>
    <li><a href="{{URL('about/management')}}">Manajemen</a></li>
    <li><a href="{{URL('about/prestasi')}}">Prestasi Perusahaan</a></li>
	<li><a href="{{URL('about/gcg')}}">GCG</a></li>
</ul>