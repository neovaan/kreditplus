<ul>
	<li class="active"><a href="{{URL('produk/elektronik')}}">Elektronik</a></li>
	<li><a href="{{URL('produk/mobil')}}">Mobil</a></li>
	<li><a href="{{URL('produk/motor')}}">Motor</a></li>
	<li><a href="{{URL('produk/pinjaman')}}">Modal Usaha</a></li>
</ul>