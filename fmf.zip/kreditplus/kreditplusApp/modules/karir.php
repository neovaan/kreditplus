<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Karir',
        'icon' => 'fa-clone',
        'tables' => [
                'karir','content_karir'
        ],
        'panels' => [
                'karir','content_karir'
        ]
];