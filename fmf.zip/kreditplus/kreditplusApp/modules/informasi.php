<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Informasi',
        'icon' => 'fa-clone',
        'tables' => [
                'informasi','type'
        ],
        'panels' => [
                'informasi','type'
        ]
];