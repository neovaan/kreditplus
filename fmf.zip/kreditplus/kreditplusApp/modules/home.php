<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Home',
        'icon' => 'fa-clone',
        'tables' => [
                'slides','layanan','produk','testimoni_user','sponsor'
        ],
        'panels' => [
                'slides','layanan','produk','testimoni_user','sponsor'
        ]
];