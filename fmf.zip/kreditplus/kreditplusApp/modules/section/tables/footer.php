<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'image', 'notnull' => true],
        ['master' => 'title', 'name' => 'txt1', 'notnull' => true,'multilingual' => true],
        ['master' => 'title', 'name' => 'txt2', 'notnull' => true,'multilingual' => true],
        ['master' => 'title', 'name' => 'link', 'notnull' => true]
       ];