<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'section_id', 'notnull' => true],
        ['master' => 'title', 'name' => 'img1', 'notnull' => true],
        ['master' => 'title', 'name' => 'img2', 'notnull' => true],
        ['master' => 'title', 'name' => 'img3', 'notnull' => true],
        ['master' => 'title', 'name' => 'img4', 'notnull' => true],
        ['master' => 'title', 'name' => 'title1', 'notnull' => true],
        ['master' => 'title', 'name' => 'title2', 'notnull' => true],
        ['master' => 'title', 'name' => 'title3', 'notnull' => true],
        ['master' => 'title', 'name' => 'title4', 'notnull' => true]
       ];