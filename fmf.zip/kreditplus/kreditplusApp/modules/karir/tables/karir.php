<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'section_id', 'notnull' => true],
        ['master' => 'title', 'name' => 'title_job'],
        ['master' => 'title', 'name' => 'penempatan'],
        ['master' => 'description', 'name' => 'description', 'multilingual' => true]
       ];