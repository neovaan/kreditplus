<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 3/23/2017
 * Time: 10:42 AM
 */

return [
        'permalink' => true,
        'group' => 'site',
        'actions' => [
                'edit'
        ]
];