<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 6/13/2017
 * Time: 3:45 PM
 */

return [
        ['master' => 'id'],
        ['master' => 'int', 'name' => 'admin_id'],
        ['master' => 'longTitle', 'name' => 'token'],
        ['master' => 'createOn', 'name' => 'expiration'],
        ['master' => 'createOn']
];