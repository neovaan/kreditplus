<?php
/**
 * Created by PhpStorm
 * Date: 05/03/2017
 * Time: 10:15
 * Author: Daniel Simangunsong
 *
 * Calm seas, never make skill full sailors
 */

return [
        ['master' => 'id'],
        ['master' => 'shortTitle', 'name' => 'template'],
        ['master' => 'shortTitle', 'name' => 'object'],
        ['master' => 'shortTitle'],
        ['master' => 'sequence'],
        'timestamps' => true
];