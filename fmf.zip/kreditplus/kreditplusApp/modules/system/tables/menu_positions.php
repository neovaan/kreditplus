<?php
/**
 * Created by PhpStorm
 * Date: 15/02/2017
 * Time: 21:41
 * Author: Daniel Simangunsong
 *
 * Calm seas, never make skill full sailors
 */

return [
        ['master' => 'id'],
        ['master' => 'int', 'name' => 'menu_id', 'uniques' => true],
        ['master' => 'shortTitle', 'name' => 'position', 'uniques' => true],
        'timestamp' => true
];