<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Contact',
        'icon' => 'fa-clone',
        'tables' => [
                'contact','testimoni','cabang'
        ],
        'panels' => [
                'contact','testimoni','cabang'
        ]
];