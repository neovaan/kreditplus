<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Kreditplus Karir',
        'icon' => 'fa-clone',
        'tables' => [
               'kreditplus_karir'
        ],
        'panels' => [
                'kreditplus_karir'
        ]
];