<?php
/**
 * Created by PhpStorm
 * Date: 18/02/2017
 * Time: 16:35
 * Author: Daniel Simangunsong
 *
 * Calm seas, never make skill full sailors
 */

return [
        'icon' => 'fa-clone',
        // 'tables' => ['pages', 'slides','banner','content','pengajuan','informasi','submenu','pengajuan_kredit','karir','kreditplus_karir','prestasi','visimisi','contact','desc_prestasi'],
        // 'panels' => [
        //         'contact','banner','content','pengajuan','informasi','pengajuan_kredit','karir','kreditplus_karir','prestasi','visimisi','desc_prestasi','informasi_home'
        // ]
        'tables' => ['banner','footer','content','mini_banner','newsletter','google_play'],
        'panels' => ['banner','footer','content','mini_banner','newsletter','google_play']
];