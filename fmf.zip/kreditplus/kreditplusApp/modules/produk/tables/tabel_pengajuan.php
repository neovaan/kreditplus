<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'section_id', 'notnull' => true],
        ['master' => 'title', 'name' => 'persyaratan', 'notnull' => true,'multilingual'=>true],
        ['master' => 'title', 'name' => 'wiraswasta', 'notnull' => true],
        ['master' => 'title', 'name' => 'karyawan', 'notnull' => true],
        ['master' => 'title', 'name' => 'profesional', 'notnull' => true]
       ];