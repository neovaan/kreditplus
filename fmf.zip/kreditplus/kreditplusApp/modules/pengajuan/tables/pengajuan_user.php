<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'nama', 'notnull' => true],
        ['master' => 'title', 'name' => 'alamat', 'notnull' => false],
        ['master' => 'title', 'name' => 'ktp', 'notnull' => false],
        ['master' => 'title', 'name' => 'telp', 'notnull' => true],
        ['master' => 'title', 'name' => 'email', 'notnull' => true],
        ['master' => 'title', 'name' => 'rya', 'notnull' => true],
        ['master' => 'title', 'name' => 'brand', 'notnull' => true],
        ['master' => 'title', 'name' => 'area', 'notnull' => true],
        ['master' => 'shortIntro', 'name' => 'pesan', 'notnull' => true, 'multilingual' => true]
       ];