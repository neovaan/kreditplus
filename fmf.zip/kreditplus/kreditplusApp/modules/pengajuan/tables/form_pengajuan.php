<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 2/16/2017
 * Time: 10:02 AM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'section_id', 'notnull' => true],
        ['master' => 'title', 'name' => 'field1', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field2', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field3', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field4', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field5', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field6', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field7', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field8', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field9', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field10', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field11', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field12', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'field13', 'notnull' => true, 'multilingual' => true],
        ['master' => 'title', 'name' => 'captcha', 'notnull' => true]
       ];