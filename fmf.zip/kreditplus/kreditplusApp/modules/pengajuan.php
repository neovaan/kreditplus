<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Pengajuan',
        'icon' => 'fa-clone',
        'tables' => [
                'brand','area','pengajuan_user','form_pengajuan'
        ],
        'panels' => [
                'brand','area','pengajuan_user','form_pengajuan'
        ]
];