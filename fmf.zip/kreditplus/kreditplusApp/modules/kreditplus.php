<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Kreditplus',
        'icon' => 'fa-clone',
        'tables' => [
                'content_kreditplus'
        ],
        'panels' => [
                'content_kreditplus'
        ]
];