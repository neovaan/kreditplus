<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 3/15/2017
 * Time: 4:54 PM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'section_id'],
        ['master' => 'title', 'name' => 'kota'],
        ['master' => 'title', 'name' => 'alamat'],
        ['master' => 'title', 'name' => 'fax'],
        ['master' => 'title','name'=>'email'],
        ['master' => 'title','name'=>'telp'],
        ['master' => 'title','name'=>'provinsi'],
        ['master' => 'title','name'=>'lat'],
        ['master' => 'title','name'=>'long'],
        ['master' => 'title','name'=>'title_name'],
        ['master' => 'title','name'=>'contact_name']
];