<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 3/15/2017
 * Time: 4:54 PM
 */

return [
        ['master' => 'id'],
        ['master' => 'title', 'name' => 'nama'],
        ['master' => 'title', 'name' => 'telp'],
        ['master' => 'title', 'name' => 'email'],
        ['master' => 'description', 'name' => 'pesan', 'multilingual' => true]
];