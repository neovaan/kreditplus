<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 3/15/2017
 * Time: 4:54 PM
 */

return [
        ['master' => 'id'],
        ['master' => 'title','name'=>'lat','notnull'=>true],
        ['master' => 'title','name'=>'long','notnull'=>true],
        ['master' => 'title','name'=>'title_name','notnull'=>true],
        ['master' => 'title','name'=>'contact_name','notnull'=>true]
    ];