<?php
/**
 * Created by PhpStorm
 * Date: 21/10/2016
 * Time: 8:38
 * Author: Daniel Simangunsong
 *
 * Note.
 *
 */

return [
        'title' => 'Produk',
        'icon' => 'fa-clone',
        'tables' => [
                'content_produk'
        ],
        'panels' => [
                'content_produk'
        ]
];