<?php if($paginator->hasPages()): ?>
	<div class="pagination">
		 <?php if(!$paginator->onFirstPage()): ?>
           <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="prev">Previous</a>
        <?php endif; ?>
		
		<?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			 <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			 		 <a href="<?php echo e($url); ?>" class="<?php echo ($page == $paginator->currentPage()) ? 'active' : '' ;?>"  ><?php echo e($page); ?></a>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		 <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next">Next</a>
        <?php endif; ?>
		
	</div>
<?php endif; ?>