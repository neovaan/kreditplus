    <?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 4/28/2017
 * Time: 4:02 PM
 */?>

<?php $__env->startSection('content'); ?>
<section class="banner">
    <div class="box-maps">
        <div id="map_location"></div>
    </div>
    <div class="submenu-banner">
        <div class="wrap-sm">
            <div class="box-submenu">
                <div class="btn-submenu">Submenu</div>
                <div class="drop-submenu">
                    <?php echo $__env->make('webarq::themes.front-end.sections.submenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="ctnwp">
<div class="wrap-sm">
<?php if([] !== $shareSections): ?>
    <?php $__currentLoopData = $shareSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <?php if($section->getKey() != 'banner'): ?>
        <?php echo $section->toHtml(); ?>

      <?php endif; ?>          
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endif; ?>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('webarq::themes.front-end.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>