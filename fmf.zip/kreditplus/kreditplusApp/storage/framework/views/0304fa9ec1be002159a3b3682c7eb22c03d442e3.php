<section class="produkkredit">
	<div class="trig-produk"></div>
	<div class="inprodukkredit a-from-bottom" delay=".3" trigger-anim=".trig-produk" style="background-image: url('<?php echo e(URL('vendor/webarq/front-end/images/content/bg-kredibilitas.jpg')); ?>');">
		<div class="bgcirc"></div>
		<div class="inprokre">
			<h3 class="a-from-bottom" delay=".8" trigger-anim=".trig-produk"><?php echo e(Wa::trans('site.label_produk_kreditplus')); ?></h3>
			<div class="circwhite">
				<div class="box-list-product slideprodhome">
					<?php $__currentLoopData = $shareData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<div class="list-product">
						<a href="<?php echo e(URL::trans($data->link)); ?>">
							<div class="in-product">
								<figure><img src="<?php echo e(URL($data->image)); ?>" alt="<?php echo e($data->title); ?>"></figure>
								<div class="desc">
									<h4><?php echo e($data->title); ?></h4>
									<p><?php echo e($data->intro); ?></p>
								</div>
							</div>
						</a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $link = ""; ?>
 <?php $__currentLoopData = Wa::menu()->getNodes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <?php if($m['id'] == "13" ): ?>
        <?php $link =  $m['permalink'];?>
         <?php if(Wa::menu()->getNode($m['id'])->getChild('first')): ?>
         	<?php  $link = Wa::menu()->getNode($m['id'])->getChild('first')->permalink;  ?>
         <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php if($info->count()): ?>
<section class="infohome">
	<div class="trig-info"></div>
	<div class="wrapper">
		<div class="title-infohome a-from-left" delay=".3" trigger-anim=".trig-info">
			<h3><?php echo e(Wa::trans('site.label_title_informasi')); ?></h3>
			<a href="<?php echo e(URL::trans($link)); ?>"><?php echo e(Wa::trans('site.label_lihat_semua')); ?></a>
		</div>
		<div class="box-infohome">
			<div class="lg-info a-from-left" delay=".5" trigger-anim=".trig-info">
				<a href="<?php echo e(URL::trans($link.'/read/'.$info[0]->permalink)); ?>">
					<figure>
						<img src="<?php echo e(URL($info[0]->image)); ?>" alt="<?php echo e($info[0]->type); ?>">
						<span class="lbl <?php echo ( ($info[0]->type == "berita") ? "lblue" : "lyellow") ;?>"><?php echo e($info[0]->type); ?></span>
					</figure>
					<div class="desc-lg-info">
						<h4><?php echo e($info[0]->title); ?></h4>
						<p><?php echo e($info[0]->intro); ?></p>
					</div>
				</a>
			</div>
			<div class="sm-info">
				<div class="box-list-info-sm">
					<?php $i = 0; ?>
					<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<?php
							$i++;
							if($i == 1)
								continue;
						?>
						<div class="list-info-sm a-from-right" delay=".8" trigger-anim=".trig-info">
							<a href="<?php echo e(URL::trans($link.'/read/'.$q->permalink)); ?>">
								<figure>
									<img src="<?php echo e(URL($q->image2)); ?>" alt="<?php echo e($q->type); ?>">
									<span class="lbl <?php echo ( ($q->type == "berita") ? "lblue" : "lyellow") ;?>"><?php echo e($q->type); ?></span>
								</figure>
								<div class="desc-sm-info">
									<h4><?php echo e($q->title); ?></h4>
									<p><?php echo e($q->intro); ?></p>
									<span class="link-blue"><?php echo e(Wa::trans('site.label_lihat_selengkapnya')); ?></span>
								</div>
							</a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>


<section class="testimonihome">
	<div class="trig-testimoni"></div>
	<div class="intestimonihome a-from-bottom" delay=".3" trigger-anim=".trig-testimoni" style="background-image: url('<?php echo e(URL('vendor/webarq/front-end/images/content/bg-testimoni.jpg')); ?>');">
	<div class="wrapper">
	<h3 class="a-from-bottom" delay=".8" trigger-anim=".trig-testimoni"><?php echo e(Wa::trans('site.label_testimoni_nasabah')); ?></h3>
	<div class="box-list-testimoni slidetestimoni">
		<?php if($testimoni->count()): ?>
		<?php $__currentLoopData = $testimoni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testi): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<div class="list-testimoni">
			<div class="inner-testimoni">
				<div class="img-testi">
					<figure><img src="<?php echo e(URL::asset($testi['image_user'])); ?>" alt="testimoni"></figure>
					<div class="ttl-testi">
						<h6><?php echo e($testi->nama); ?></h6>
						<span><?php echo e($testi->pekerjaan); ?></span>
					</div>
				</div>
				<div class="ctn-testi">
					<?php echo e($testi->pesan); ?>

				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
	</div>
	</div>
	</div>
</section>