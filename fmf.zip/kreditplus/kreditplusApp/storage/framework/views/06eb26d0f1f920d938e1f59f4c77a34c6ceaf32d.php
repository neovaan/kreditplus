<h3 class="tblue"><?php echo e($shareData[0]->title); ?></h3>
<p><?php echo $shareData[0]->description;?></p>
<br>
<br>
<div class="a-center">
	<img src="<?php echo e(URL($shareData[0]->image)); ?>">
</div>