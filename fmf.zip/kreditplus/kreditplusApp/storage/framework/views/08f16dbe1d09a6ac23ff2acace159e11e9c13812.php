<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 1/17/2017
 * Time: 2:46 PM
 */ ?>
<section class="content-header">
    <h1>
        <?php echo e(title_case($shareModule->getTitle())); ?>

        <small><?php echo e(title_case($sharePanel->getTitle())); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"><?php echo e(title_case($shareModule->getTitle())); ?></a></li>
        <?php if(!is_null($shareBreadCrumbAction)): ?>
            <li><?php echo e(title_case($sharePanel->getTitle())); ?></li>
            <li class="active"><?php echo e(title_case($shareBreadCrumbAction)); ?></li>
        <?php else: ?>
            <li class="active"><?php echo e(title_case($sharePanel->getTitle())); ?></li>
        <?php endif; ?>
    </ol>
</section>
