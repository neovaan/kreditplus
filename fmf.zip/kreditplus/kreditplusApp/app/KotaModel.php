<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KotaModel extends Model
{
    protected $table = 'regencies';
}
