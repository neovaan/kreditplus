<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class KreditplusKarirModel extends AbstractListingModel
{
    protected $table = 'kreditplus_karir';
}