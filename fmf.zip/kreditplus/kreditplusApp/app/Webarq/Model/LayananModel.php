<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class LayananModel extends AbstractListingModel
{
    protected $table = 'layanan';
}