<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class TypeModel extends AbstractListingModel
{
    protected $table = 'type';
}