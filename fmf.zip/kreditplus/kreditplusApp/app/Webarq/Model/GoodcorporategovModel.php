<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class GoodcorporategovModel extends AbstractListingModel
{
    protected $table = 'goodcorporategov';
}