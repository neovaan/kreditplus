<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ContentKreditplusModel extends AbstractListingModel
{
    protected $table = 'content_kreditplus';
}