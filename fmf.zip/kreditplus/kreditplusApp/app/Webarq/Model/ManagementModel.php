<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ManagementModel extends AbstractListingModel
{
    protected $table = 'management';
}