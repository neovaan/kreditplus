<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ProdukModel extends AbstractListingModel
{
    protected $table = 'produk';
}