<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class PengajuanModel extends AbstractListingModel
{
    protected $table = 'pengajuan';
}