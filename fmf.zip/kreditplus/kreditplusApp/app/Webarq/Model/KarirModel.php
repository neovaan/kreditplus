<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class KarirModel extends AbstractListingModel
{
    protected $table = 'karir';
}