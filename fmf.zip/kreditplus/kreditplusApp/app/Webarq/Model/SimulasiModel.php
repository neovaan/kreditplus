<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class SimulasiModel extends AbstractListingModel
{
    protected $table = 'simulasi';
}