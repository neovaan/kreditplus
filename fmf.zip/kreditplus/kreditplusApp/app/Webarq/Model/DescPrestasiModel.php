<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class DescPrestasiModel extends AbstractListingModel
{
    protected $table = 'desc_prestasi';
}