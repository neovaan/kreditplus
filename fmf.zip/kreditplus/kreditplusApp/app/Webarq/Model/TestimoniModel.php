<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class TestimoniModel extends AbstractListingModel
{
    protected $table = 'testimoni';
}