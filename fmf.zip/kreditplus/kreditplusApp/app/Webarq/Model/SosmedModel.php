<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class SosmedModel extends AbstractListingModel
{
    protected $table = 'sosmed';
}