<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class SubmenuModel extends AbstractListingModel
{
    protected $table = 'submenu';
}