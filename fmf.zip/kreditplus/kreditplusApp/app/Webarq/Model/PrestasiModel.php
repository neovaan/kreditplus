<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class PrestasiModel extends AbstractListingModel
{
    protected $table = 'prestasi';
}