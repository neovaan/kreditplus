<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class BrandModel extends AbstractListingModel
{
    protected $table = 'brand';
}