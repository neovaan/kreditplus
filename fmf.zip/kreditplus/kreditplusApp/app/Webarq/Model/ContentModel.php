<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ContentModel extends AbstractListingModel
{
    protected $table = 'content';
}