<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class PengajuanKreditModel extends AbstractListingModel
{
    protected $table = 'pengajuan_kredit';
}