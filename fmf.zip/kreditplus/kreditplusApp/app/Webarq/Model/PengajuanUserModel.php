<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class PengajuanUserModel extends AbstractListingModel
{
    protected $table = 'pengajuan_user';
}