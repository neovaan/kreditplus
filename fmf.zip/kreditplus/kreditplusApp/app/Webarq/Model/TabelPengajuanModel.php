<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class TabelPengajuanModel extends AbstractListingModel
{
    protected $table = 'tabel_pengajuan';
}