<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class FormPengajuanModel extends AbstractListingModel
{
    protected $table = 'form_pengajuan';
}