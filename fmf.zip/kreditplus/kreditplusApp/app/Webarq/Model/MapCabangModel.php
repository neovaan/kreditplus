<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class MapCabangModel extends AbstractListingModel
{
    protected $table = 'map_cabang';
}