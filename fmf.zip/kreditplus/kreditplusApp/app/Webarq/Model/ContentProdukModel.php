<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ContentProdukModel extends AbstractListingModel
{
    protected $table = 'content_produk';
}