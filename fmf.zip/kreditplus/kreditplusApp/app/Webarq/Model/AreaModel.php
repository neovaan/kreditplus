<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class AreaModel extends AbstractListingModel
{
    protected $table = 'area';
}