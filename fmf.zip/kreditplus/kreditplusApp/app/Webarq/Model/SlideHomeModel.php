<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class SlideHomeModel extends AbstractListingModel
{
    protected $table = 'slide_home';
}