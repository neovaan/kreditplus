<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ProdukHomeModel extends AbstractListingModel
{
    protected $table = 'produk_home';
}