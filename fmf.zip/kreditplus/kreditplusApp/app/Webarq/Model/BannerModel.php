<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class BannerModel extends AbstractListingModel
{
    protected $table = 'banner';
}