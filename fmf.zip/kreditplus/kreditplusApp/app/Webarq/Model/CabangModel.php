<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class CabangModel extends AbstractListingModel
{
    protected $table = 'cabang';
}