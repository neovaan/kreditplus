<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class FooterModel extends AbstractListingModel
{
    protected $table = 'footer';
}