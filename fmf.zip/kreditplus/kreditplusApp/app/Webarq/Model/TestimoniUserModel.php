<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class TestimoniUserModel extends AbstractListingModel
{
    protected $table = 'testimoni_user';
}