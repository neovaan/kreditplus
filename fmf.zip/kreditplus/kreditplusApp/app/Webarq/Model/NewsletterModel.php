<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class NewsletterModel extends AbstractListingModel
{
    protected $table = 'newsletter';
}