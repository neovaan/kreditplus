<?php

namespace App\Webarq\Model;


use Webarq\Model\AbstractListingModel;

class ServiceHomeModel extends AbstractListingModel
{
    protected $table = 'service_home';
}