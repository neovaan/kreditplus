<?php
/**
 * Created by PhpStorm.
 * User: DanielSimangunsong
 * Date: 6/19/2017
 * Time: 3:26 PM
 */

namespace Webarq\Http\Controllers\Site;
use App\Http\Controllers\Site\BaseController;


class ImageController extends BaseController
{
    public function actionGetIndex()
    {
    }
}