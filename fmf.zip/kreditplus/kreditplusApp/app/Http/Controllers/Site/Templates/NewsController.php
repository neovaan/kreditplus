<?php
/**
 * Created by PhpStorm
 * Date: 26/02/2017
 * Time: 13:06
 * Author: Daniel Simangunsong
 *
 * Calm seas, never make skill full sailors
 */

namespace Webarq\Http\Controllers\Site\Templates;


use Webarq\Http\Controllers\Site\BaseController;

class NewsController extends BaseController
{
    protected $layout = 'news';

    public function actionGetIndex()
    {

    }

    public function actionGetRead()
    {

    }
}